<?php 
include("config/config.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Properties</title>
<style>
		
	* {
			box-sizing: border-box;
		}

		body {
			font-family: Arial, Helvetica, sans-serif;
			margin: 0px;
     
		}

		.header {
			padding: 80px;
			text-align: center;
			background: #1abc9c;
			color: white;
		}

		.row {
			display: flex;
			flex-wrap: wrap;
			/* padding: 0 4px; */
		}

		/* Create two equal columns that sits next to each other */
		.column {
			flex: 50%;
			padding: 0 4px;
		}

		.card {
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			max-width: 80%;
			min-width: 80%;
			margin: auto;
			text-align: center;
			font-family: arial;
			display: flex;
			position: relative;
			transition: all 0.3s ease-in-out;
      border: 4px solid f2f2f2;
      border-radius : 40px;
      background-color: f2f2f2;
      padding: 1.5rem 1.5rem;
		}

		.card:hover {
			box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
			opacity: 0.8;
			transform: translateY(-5px);
		}

		.container {
			padding: 2px 16px;
      display:flex;
      justify-content:center;
      flex-direction:column;
      align-items:center;
		}

		.btn {
			width: 30vh;
			background-color: #1abc9c;
			color: white;
			border: none;
			padding: 12px;
			cursor: pointer;
			font-size: 16px;
			border-radius: 4px;
			transition: all 0.3s ease-in-out;
		}

		.btn:hover {
			background-color: #148f77;
			transform: scale(1.05);
		}

		.image {
			min-width: 30%;
			min-height: 200px;
			max-width: 30%;
			max-height:200px;
      border: 4px solid f2f2f2;
      border-radius : 40px;
		}
</style>
</head>
<body>
	<div class="row">
		<?php 

		$sql="SELECT * FROM add_property";
		$query=mysqli_query($db,$sql);

		if(mysqli_num_rows($query)>0)
		{
			while ($rows=mysqli_fetch_assoc($query)) {
				$property_id=$rows['property_id'];
				?>

				<div class="column">
					<div class="card">
						<?php
						$sql2="SELECT * FROM property_photo where property_id='$property_id'";
						$query2=mysqli_query($db,$sql2);

						if(mysqli_num_rows($query2)>0)
						{
							$row=mysqli_fetch_assoc($query2); 
							$photo=$row['p_photo'];
							echo '<img class="image" src="owner/'.$photo.'">';
						}
						?>

						<div class="container">
							<h4><b><?php echo $rows['property_type']; ?></b></h4> 
							<p><?php echo $rows['city'].', '.$rows['district'] ?></p> 
							<p><?php echo '<a href="view-property.php?property_id='.$rows['property_id'].'"  class="btn btn-lg btn-primary btn-block" >View Property </a><br>'; ?></p><br>
						</div>
					</div>
				</div>

			<?php 
			}
		}
		?>

	</div>
</body>

</html> 
