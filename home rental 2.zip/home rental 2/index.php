<?php 
session_start();

include("navbar.php");

 ?>
 
 <link rel="stylesheet" href="css/all.min.css">
 <style> 
body, html {
  height: 95%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("images/carousel/img3.jpg");
  background-color: #f2f2f2;

  /* Full height */
  height: 75%; 
  width: 100%;
  display: flex;
  justify-content : center;
  align-items: center;

  /* Center and scale the image nicely */
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
  z-index: -2;

  
}
.bg::after {
  content: "";
  position: absolute;
  width: 100%;
  height: 67.5%;
  background-color: rgba(0,0,0,0.7); /* change the opacity value as needed */
  z-index: 0;
}

/* heading  */

/* Heading container */
.heading-container {
  height: 200px;
  z-index: 1;
}

/* Heading */
.heading {
  font-family: 'Montserrat', sans-serif;
  font-size: 4rem;
  font-weight: bold;
  color: white;
  text-transform: uppercase;
  text-align: center;
  animation: fadein 2s;
  margin-top: 5vh;
  z-index: 1;
}

/* Animation */
@keyframes fadein {
  from { opacity: 0; }
  to   { opacity: 1; }
}

/* search bar  */

.search-container {
  position: relative;
}

input[type="text"] {
  width: 100%;
  padding: 10px;
  border-radius: 20px;
  background-color: rgba(255, 255, 255, 0.8);
  border: none;
  outline: none;
  font-size: 18px;
  color: #000;
  transition: all 0.3s ease-in-out;
}

input[type="text"]:focus {
  background-color: rgba(255, 255, 255, 1);
  box-shadow: 0px 0px 5px #fff;
}

.search-icon {
  position: absolute;
  top: 50%;
  right: 15px;
  transform: translateY(-50%);
  cursor: pointer;
  opacity: 0.5;
  transition: all 0.3s ease-in-out;
}

.search-icon:hover {
  opacity: 1;
}

.search-icon i {
  font-size: 24px;
  color: #000;
}

input[type="text"]:focus ~ .search-icon {
  opacity: 1;
  right: 35px;
}

input[type="text"]:focus ~ .search-icon i {
  color: #fff;
}

</style>
<div class="bg" >
  <div class="heading-container" >
  <div class="search-container">
  <form method="POST" action="search-property.php">
    <input type="text" class="form-control" name="search_property" placeholder="Search">
  </form>
  <div class="search-icon">
    <i class="fa fa-search"></i>
  </div>
</div>
   <h1 class="heading">Home Rental Services</h1>     
  </div>
</div>
<br>
<div class="container active-cyan-4 mb-4 inline">	
</div>
<br><br>
</div>
   <h1 class="heading" style="color:black; margin:4rem; font-size: 3rem;">PROPERTIES</h1>     
  </div>
<?php 

include("property-list.php");

 ?>
 <br><br>