<?php 
session_start();

include("navbar.php");

 ?>
 
 <!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	<style>
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: Arial, sans-serif;
		}

		body {
			background-color: #f2f2f2;
		}

		h1 {
			text-align: center;
			padding-top: 50px;
			font-size: 2.5rem;
			color: #333;
		}

		form {
			margin: 50px auto;
			width: 500px;
			background-color: #fff;
			padding: 20px;
			box-shadow: 0 0 10px rgba(0,0,0,0.2);
		}

		input[type="text"], textarea {
			display: block;
			width: 100%;
			padding: 10px;
			margin-bottom: 10px;
			border-radius: 5px;
			border: none;
			box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.1);
			resize: none;
			font-size: 1rem;
		}

		textarea {
			height: 100px;
		}

		input[type="submit"] {
			display: block;
			background-color: #333;
			color: #fff;
			border: none;
			border-radius: 5px;
			padding: 10px 20px;
			cursor: pointer;
			transition: all 0.3s ease-in-out;
		}

		input[type="submit"]:hover {
			background-color: #fff;
			color: #333;
		}
	</style>
</head>
<body>
	<h1>Contact Us</h1>
	<form>
		<label for="name">Name:</label>
		<input type="text" id="name" name="name" required>

		<label for="email">Email:</label>
		<input type="text" id="email" name="email" required>

		<label for="message">Message:</label>
		<textarea id="message" name="message" required></textarea>

		<input type="submit" value="Send Message">
	</form>
</body>
</html>
