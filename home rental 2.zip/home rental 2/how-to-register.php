<?php 
session_start();
if(isset($_SESSION["email"])){
  header("location:index.php");
}
include("navbar.php");

?>

<style>
    .sign-up button {
        animation-duration: 2s;
        animation-name: button-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes button-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .sign-up h3 {
        animation-duration: 1s;
        animation-name: heading-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes heading-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .sign-up p {
        animation-duration: 1.5s;
        animation-name: text-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes text-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    .sign-in-form-section {
  background-image: url('./images/carousel/img5.jpg');
  background-size: cover;
  background-position: center;
  height:94.5vh;
  z-index: -2;
    }
    .sign-in-form-section::after{
  content: "";
  position: absolute;
  width: 100%;
  top:6.75vh;
  left:0%;
  height: 93.3vh;
  background-color: rgba(0,0,0,0.7); /* change the opacity value as needed */
  z-index: 0;
   }
   #mainbox{
    margin-top:25vh;
    z-index:1;
   }

   .btn {
			width: 30vh;
			background-color: black;
			color: white;
			border: none;
			padding: 12px;
			cursor: pointer;
			font-size: 16px;
			border-radius: 4px;
			transition: all 0.3s ease-in-out;
            margin: 0px 5px; 
		}

		.btn:hover {
			background-color: white;
            color:black;
			transform: scale(1.05);
		}

</style>

<section class="container-fluid sign-in-form-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 sign-up" id="mainbox" style="text-align: center;">
                <h3 style="font-weight: bold; color:white;">How do you want to Register?</h3><hr>
                <p style="color:white;">If you want to register as a tenant click on the "Tenant Register" button. Otherwise, click on the "Owner Register" button.</p><br><br>
                <button class="btn" type="submit" class="btn btn-info"  onclick="window.location.href='tenant-register.php'" style="width:200px;">Tenant Register</button>
                <button class="btn" type="submit" class="btn btn-info"  onclick="window.location.href='owner-register.php'" style="width:200px;">Owner Register</button>
            </div>
        </div>
    </div>
</section>
