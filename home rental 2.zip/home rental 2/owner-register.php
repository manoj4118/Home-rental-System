<?php 

include("navbar.php");

 ?>
<style>
  body {
    background-image: url('./images/carousel/img6.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      z-index:-1;
  }
  body::after{
  content: "";
  position: fixed;
  width: 100%;
  top:0vh;
  left:0%;
  min-height: 140.5vh;
  max-height: 160vh;
  background-color: rgba(0,0,0,0.8); /* change the opacity value as needed */
  z-index: -1;
   }
 .container{
  padding: 0px 50vh;
  margin: 6vh 20vh;
  
  }
  form{
  border: 2px solid white;
  z-index:1;
  border-radius:30px;
  }
  form label{
  color:white;
  } 
  .form-group{
  margin:20px;
  }  
  .btn {
			width: 30vh;
			background-color: black;
			color: white;
			border: none;
			padding: 12px;
			cursor: pointer;
			font-size: 16px;
			border-radius: 4px;
			transition: all 0.3s ease-in-out;
      opacity:0.8;
      margin-top:4vh;
		}

		.btn:hover {
			background-color: white;
      color:black;
			transform: scale(1.05);
		}
    .form-control,option {
    border: none;
    border-bottom: 2px solid #ccc;
    padding: 10px;
    color:white;
    font-size: 16px;
    background-color: transparent;
    transition: all 0.3s ease-in-out;
    position: relative;
  }
  
  .form-control:focus {
    outline: none;
    border-bottom: 2px solid #3498db;
  }
  
  .form-control:before,
  .form-control:after {
    content: '';
    height: 2px;
    width: 0;
    bottom: 0;
    position: absolute;
    background: #3498db;
    transition: all 0.3s ease-in-out;
  }
  
  .form-control:before {
    left: 50%;
  }
  
  .form-control:after {
    right: 50%;
  }

</style>
<div class="container">
  <h3 style="font-weight: bold; text-align: center;color:white;">Owner Register</h3><hr><br>
  <form method="POST" action="owner-engine.php" enctype="multipart/form-data">
    <div class="form-group">
      <label for="full_name">Full Name:</label>
      <input type="text" class="form-control" id="full_name"  name="full_name" required>
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email"  name="email" required>
    </div>
    <div class="form-group">
      <label for="password1">Password:</label>
      <input type="password" class="form-control" id="password1" ="Enter Password" name="password" required>
    </div>
    <div class="form-group">
      <label for="password2">Confirm Password:</label>
      <input type="password" class="form-control" id="password2" ="Enter Password Again" required>
    </div>
    <div class="form-group">
      <label for="phone_no">Phone No.:</label>
      <input type="text" class="form-control" id="phone_no" ="Enter Phone No." name="phone_no" required>
    </div>
    <div class="form-group">
      <label for="address">Address:</label>
      <input type="text" class="form-control" id="address" ="Enter Address" name="address" required>
    </div>
    <div class="form-group">
      <label for="id_type">Type of ID:</label>
      <select class="form-control" name="id_type" required>
        <option></option>
        <option>Driving Licence</option>
        <option>Aadhar</option>
        <option>Passport</option>
        <option>Voter Id</option>
      </select>
    </div>
    <div class="form-group">
      <label for="card_photo">Upload your Selected Card:</label>
      <input type="file" class="form-control" placeholder="Enter password" name="id_photo" accept="image/*" onchange="preview_image(event)" required>
    </div>
    <div class="form-group">
      <label>Your selected File:</label><br>
      <img src="" id="output_image"/ height="200px">
    </div>

    <center><button id="submit" name="owner_register" class="btn btn-primary btn-block" onclick="return Validate()">Register</button></center><br>
    <div class="form-group text-right">
      <label class="">Register as a <a href="tenant-register.php">Tenant</a>?</label><br>
    </div><br><br>
  </form>
</div>

<script type='text/javascript'>
        function preview_image(event)
        {
            var reader = new FileReader();
            reader.onload = function()
            {
                var output = document.getElementById('output_image');
                output.src = reader.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
    <script type="text/javascript">
    function Validate() {
        var password = document.getElementById("password1").value;
        var confirmPassword = document.getElementById("password2").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>