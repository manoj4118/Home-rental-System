<?php 
session_start();
if(!isset($_SESSION["email"])){
  header("location:index.php");
}
include('navbar.php');
include('tenant-engine.php');
 ?>
<style>
	.container {
    padding: 20px;
    border-radius: 5px;
    margin-top: 20px;
  }
	.card {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
    max-width:100%;
    background: #F0F0F0;
    margin: 2vh;
    text-align: center;
    font-family: 'Arial', sans-serif;
    transition: transform 0.3s ease-in-out;
    border-radius: 5px;
    overflow: hidden;
    display: flex;
    flex-direction:row;
    justify-content: center;
    align-items:center;
  }
  .infobox{
    display: flex;
    flex-direction:column;
    justify-content: center;
    align-items:center;
    margin: 5vh 10vh;
  }
  .card:hover {
    transform: scale(1.05);
  }
  .card img {
    height:150px;
    width: 100%;
    object-fit: cover;
  }
  .card h1 {
    font-size: 24px;
    margin: 10px 0;
    text-transform: uppercase;
  }
  .card p {
    margin: 5px 0;
  }
  button {
    width: 30vh;
			background-color: #1abc9c;
			color: white;
			border: none;
			padding: 12px;
			cursor: pointer;
			font-size: 16px;
			border-radius: 4px;
			transition: all 0.3s ease-in-out;
      margin-top: 20px;
  }

  button:hover {
    background-color: #148f77;
			transform: scale(1.05);
  }

  .form-group {
    text-align: left;
  }

  #output_image {
    height: 100px;
  }

  @font-face {
    font-family: 'Montserrat';
    src: url('https://fonts.googleapis.com/css?family=Montserrat&display=swap');
  }

  h3 {
    font-family: 'Montserrat', sans-serif;
    font-size: 36px;
    margin-top: 20px;
    margin-bottom: 30px;
  }
  main{
    margin:6rem;
  }
</style>

<main>
 <center><h3 >TENANT PROFILE</h3></center>
      <div class="container">
      <?php 
        include("config/config.php");
        $u_email= $_SESSION["email"];

        $sql="SELECT * from tenant where email='$u_email'";
        $result=mysqli_query($db,$sql);

        if(mysqli_num_rows($result)>0)
      {
          while($rows=mysqli_fetch_assoc($result)){
          
       ?>
        <div class="card">
          <img src="images/avatar_tenant.png" alt="John" style="height:100%; width: 50%; padding: 10vh">
  <div class="infobox">
  <h1><?php echo $rows['full_name']; ?></h1>
  <p class="title"><b>G-mail  : </b><?php echo $rows['email']; ?></p>
  <p><b>Phone No  : </b><?php echo $rows['phone_no']; ?></p>
  <p><b>Address   : </b><?php echo $rows['address']; ?></p>
  <p><b>Id Type   : </b><?php echo $rows['id_type']; ?></p>
  <p><img src="<?php echo $rows['id_photo']; ?>" height="100px"></p>

  <!-- Trigger the modal with a button -->
  <p><button type="button" class="btn btn-lg" data-toggle="modal" data-target="#myModal">Update Profile</button></p>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update Profile</h4>
        </div>
        <div class="modal-body">

            <form method="POST">
                <div class="form-group">
                  <label for="full_name">Full Name:</label>
                  <input type="hidden" value="<?php echo $rows['tenant_id']; ?>" name="tenant_id">
                  <input type="text" class="form-control" id="full_name" value="<?php echo $rows['full_name']; ?>" name="full_name">
                </div>
                <div class="form-group">
                  <label for="email">Email:</label>
                  <input type="email" class="form-control" id="email" value="<?php echo $rows['email']; ?>" name="email" readonly>
                </div>
                <div class="form-group">
                  <label for="phone_no">Phone No.:</label>
                  <input type="text" class="form-control" id="phone_no" value="<?php echo $rows['phone_no']; ?>" name="phone_no">
                </div>
                <div class="form-group">
                  <label for="address">Address:</label>
                  <input type="text" class="form-control" id="address" value="<?php echo $rows['address']; ?>" name="address">
                </div>
                <div class="form-group">
      <label for="id_type">Type of ID:</label>
      <input type="text" class="form-control" value="<?php echo $rows['id_type']; ?>" name="id_type" readonly>
    </div>
    <div class="form-group">
      <label>Your Id:</label><br>
      <img src="<?php echo $rows['id_photo']; ?>" id="output_image"/ height="100px" readonly>
    </div>
                <hr>
                <center><button id="submit" name="tenant_update" class="btn btn-primary btn-block">Update</button></center><br>
                
              </form>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  




</div>
<?php }} ?>

</main>