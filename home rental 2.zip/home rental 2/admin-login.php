<?php 
session_start();
if(isset($_SESSION["email"])){
  header("location:admin/admin-index.php");
}

include("navbar.php");
include("admin-engine.php");

 ?>
<head>
<style>
    .container button {
        animation-duration: 2s;
        animation-name: button-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes button-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .container h3 {
        animation-duration: 1s;
        animation-name: heading-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes heading-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .container p {
        animation-duration: 1.5s;
        animation-name: text-fadein;
        animation-fill-mode: forwards;
        opacity: 0;
    }

    @keyframes text-fadein {
        from {
            opacity: 0;
            transform: translateY(-50px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    body{
  background-image: url('./images/carousel/img.jpg');
  background-size: cover;
  background-position: center;
  height:94.5vh;
  z-index: -2;
    }
    body::after{
  content: "";
  position:fixed;
  width: 100%;
  top:0%;
  left:0%;
  min-height: 93.3vh;
  min-height: 100vh;
  background-color: rgba(0,0,0,0.7); /* change the opacity value as needed */
  z-index: -2;
   }
   .container{
    margin-top:25vh;
    z-index:2;
    padding:10px 400px;
   }

   .btn {
			width: 30vh;
			background-color: black;
			color: white;
			border: none;
			padding: 12px;
			cursor: pointer;
			font-size: 16px;
			border-radius: 4px;
			transition: all 0.3s ease-in-out;
      margin: 40px 5px; 
		}

		.btn:hover {
			background-color: white;
            color:black;
			transform: scale(1.05);
		}
    form {
  border: 1px solid white;
  border-radius: 30px;
  padding: 3vh;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
  transition: all 0.5s ease-in-out;
 }

 form:hover {
  transform: scale(1.05);
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.4);
 }


  form label{
  color:white;
  } 
  .form-group{
  margin:20px;
 
 }  
 #butt_on{
  width: 50%;
 }
 .form-control,option {
    border: none;
    border-bottom: 2px solid #ccc;
    padding: 10px;
    color:white;
    font-size: 16px;
    background-color: transparent;
    transition: all 0.3s ease-in-out;
    position: relative;
  }
  
  .form-control:focus {
    outline: none;
    border-bottom: 2px solid #3498db;
  }
  
  .form-control:before,
  .form-control:after {
    content: '';
    height: 2px;
    width: 0;
    bottom: 0;
    position: absolute;
    background: #3498db;
    transition: all 0.3s ease-in-out;
  }
  
  .form-control:before {
    left: 50%;
  }
  
  .form-control:after {
    right: 50%;
  }
</style>
</head>
<div class="container">
  <!-- <h3 style="font-weight: bold; text-align: center;">Admin Login</h3><hr><br><br> -->
  <form method="POST">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required>
    </div>
    <div class="form-group">
      <a href="forgot-password-owner.php">Lost your Password ? </a> 
    </div>
    <center><input type="submit" id="submit" name="admin_login" class="btn btn-primary btn-block" value="Login"></center>
  </form>
</div>