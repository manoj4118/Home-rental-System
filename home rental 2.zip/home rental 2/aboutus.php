<?php 
session_start();

include("navbar.php");

 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
  <title>RentHouse</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <style>
/* Reset styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Body styles */
body {
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
}
header {
  background-color: #f2f2f2;
  color: #fff;
  padding: 1rem;
  margin-bottom: -3rem;
}


/* Main styles */
main {
  background-color: #f2f2f2;
}
/* Intro section styles */
#intro {
  background: url('./images/img_1.jpg') no-repeat center center/cover;
  background-color: rgba(255, 255, 255, 0.9);
  height: 400px;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}


.container {
  text-align: center;
}

h1 {
  font-size: 4rem;
  margin-bottom: 1rem;
  color: white;
  -webkit-text-stroke: 0.7px black; /* for webkit-based browsers */
  text-stroke: 0.7px black; /* for other browsers */
}

.container1 p {
  font-size: 1.7rem;
  color: white;
  -webkit-text-stroke: 0.3px black; /* for webkit-based browsers */
  text-stroke: 0.3px black; /* for other browsers */
}

/* Our Team section styles */
#our-team {
  padding: 2rem 0;
  background:#f2f2f2;
}

h2 {
  text-align: center;
  margin-bottom: 2rem;
  color:black;
}

.box-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}

.box {
  background-color: #fff;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  border-radius: 10px;
  overflow: hidden;
  margin: 5rem;
  width: 300px;
  text-align: center;
  transition: transform 0.3s ease-in-out;
}

.box:hover {
  transform: scale(1.05);
}

.box img {
  width: 100%;
  height: 300px;
  object-fit: cover;
}

h3 {
  font-size: 1.5rem;
  margin: 1rem 0;
}

p {
  font-size: 1.25rem;
  margin-bottom: 1rem;
}

/* Mission section styles */
#mission {
  background-color: #f2f2f2;
  color: #fff;
  padding: 2rem 4rem;
}

.mission-box {
  background-color: #fff;
  color: black;
  margin: 4rem;
  padding: 6rem;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.mission-box h3 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.mission-box p {
  font-size: 1.25rem;
  margin-bottom: 1rem;
}

/* Footer styles */
footer {
  background-color: #333;
  color: #fff;
  text-align: center;
  padding: 3rem;
}

</style>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us | Home Rental Services</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main>
    <section id="intro">
      <div class="container1">
        <h1>Welcome to Home Rental Services</h1>
        <p>We are a team of experienced real estate professionals dedicated to providing high-quality rental properties to our clients.</p>
      </div>
    </section>

    <section id="our-team">
      <div class="container">
        <h2>Our Team</h2>
        <div class="box-container">
          <div class="box">
            <img src="./images/Sameet1.png" alt="Team Member 1">
            <h3>Sameet Multani</h3>
            <p>Founder & CEO</p>
          </div>

          <div class="box">
            <img src="./images/Rahul1.png" alt="Team Member 2">
            <h3>Rahul Mane</h3>
            <p>Head of Operations</p>
          </div>

          <div class="box">
            <img src="./images/Manoj1.png" alt="Team Member 3">
            <h3>Manoj Khot</h3>
            <p>Marketing Manager</p>
          </div>

          <div class="box">
            <img src="./images/Sumit1.png" alt="Team Member 4">
            <h3>Sumit Nikam</h3>
            <p>Customer Service</p>
          </div>
        </div>
      </div>
    </section>

    <section id="mission">
      <div class="container">
        <h2>Our Mission </h2>
        <div class="box-container">
          <div class="box mission-box">
            <h3>Provide Quality Rental Properties</h3>
            <p>Our goal is to provide high-quality rental properties that meet the needs and preferences of our clients.</p>
          </div>

          <div class="box mission-box">
            <h3>Deliver Exceptional Customer Service</h3>
            <p>We strive to provide exceptional customer service and ensure that our clients have a positive rental experience.</p>
          </div>

          <div class="box mission-box">
            <h3>Build Long-Term Relationships</h3>
            <p>We believe in building long-term relationships with our clients and maintaining open communication to meet their changing needs.</p>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2023 Home Rental Services. All Rights Reserved.</p>
  </footer>
</body>
</html>

